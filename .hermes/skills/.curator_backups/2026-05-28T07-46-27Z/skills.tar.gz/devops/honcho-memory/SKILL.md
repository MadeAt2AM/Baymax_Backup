---
name: honcho-memory
description: "Honcho memory backend for Hermes: API structure, tool usage, server status probes, and integration config."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [memory, honcho, persistent-memory, profile, recall]
    related_skills: [hermes-agent]
---

# Honcho Memory

Honcho is the active memory provider for this host (Chris / Baymax, workspace `baymax-core`).

## Integration Config

Config file: `~/.hermes/honcho.json`

```json
{
  "hosts": {
    "hermes": {
      "peerName": "Chris",
      "aiPeer": "Baymax",
      "workspace": "baymax-core",
      "observationMode": "directional",
      "writeFrequency": "async",
      "recallMode": "hybrid",
      "dialecticCadence": 2,
      "dialecticReasoningLevel": "max",
      "sessionStrategy": "per-directory",
      "enabled": true,
      "saveMessages": true
    }
  },
  "baseUrl": "https://honcho.madeat2am.in"
}
```

## Provider Config

In `~/.hermes/config.yaml`:

```yaml
provider: honcho
honcho: {}
memory:
  provider: honcho
  memory_enabled: true
  user_profile_enabled: true
```

## Available Honcho Tools

These are called directly by name (not via terminal):

- **`honcho_profile`** — returns user profile facts. First turn returns empty state (no facts accumulated yet). Accumulation is cadence-driven.
- **`honcho_search`** — FTS5 search over raw conversation excerpts. Optional `peer` filter (e.g., `user`). Returns match excerpts with session context.
- **`honcho_reasoning`** — synthesized answers from raw conversation data. Takes `query` + `reasoning_level` (minimal/low/medium/high/max).
- **`honcho_conclude`** — save a durable fact about the user or environment.
- **`honcho_context`** — raw peer context injection (used by dialectic layer).

## Known API Routes (honcho.madeat2am.in)

| Route | Method | Auth | Response |
|-------|--------|------|----------|
| `/health` | GET | None | `{"status":"ok"}` |
| `/` | GET | None | 404 (not a web UI) |
| `/v1` | GET | None | 404 |
| `/v1/health` | GET | None | 404 |
| `/v1/peers` | GET | None | 404 (not implemented) |
| `/api/*` | any | — | 404 |

**Key finding:** The server responds to `/health` without credentials. The peers and API routes are either not implemented or require a different API version path. Do NOT assume a 404 means the server is down — check `/health` first.

## Server Health Check

```bash
curl -s https://honcho.madeat2am.in/health
# Expected: {"status":"ok"}
```

## Tool Behavior Notes

- `honcho_profile` returns `{"No profile facts available yet."}` on a fresh workspace — this is normal, not an error.
- `honcho_search` returns `{"No relevant context found."}` when FTS5 returns no hits — this is normal, not an error.
- honcho tools do NOT require API key authentication in the request — auth is handled by the Hermes honcho plugin integration internally.
- Terminal-based honcho CLI is NOT installed on this host (`which honcho` returns empty) — the honcho integration is plugin-based only.

## Session Strategy

- `sessionStrategy: per-directory` — each directory gets its own session context.
- `recallMode: hybrid` — combines FTS5 search with generated reasoning.
- `dialecticCadence: 2` + `dialecticReasoningLevel: max` — dialectic reasoning runs every 2 turns at max depth.

## Troubleshooting

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| `honcho_profile` returns empty on turn 1 | Fresh workspace, no facts yet accumulated | Normal — facts accumulate over session turns |
| All honcho tools return auth errors | Honcho plugin not loaded | Check `hermes honcho status` |
| Server unreachable | Network or server outage | `curl -s https://honcho.madeat2am.in/health` |
| 404 on every route except /health | Route not implemented or wrong API version | Check `/health` to confirm server is up |