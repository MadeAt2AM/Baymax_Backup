---
name: deployment-checklist
description: "Pre-deployment and post-deployment verification checklist for web applications — covers networking, secrets, migrations, smoke tests, and rollback"
category: devops
tags: [deployment, checklist, ci-cd, verification, smoke-test, rollback]
---

# Deployment Checklist — Web Applications

## Pre-Deploy (Before Any `docker compose up` / Push)

### Infrastructure & Networking
- [ ] **Host MTU recorded** — `ip link show eth0 | grep mtu` → documented in PROJECT_INDEX.md
- [ ] **Docker network MTU matches host** — `driver_opts: com.docker.network.driver.mtu: "<HOST_MTU>"` in compose
- [ ] **All services on explicit custom network** — no service uses implicit `default` bridge
- [ ] **Database service on same network as app** — verified in compose file
- [ ] **External dependencies reachable** — SMTP host, payment gateway, object storage, etc. resolvable from host

### Secrets & Configuration
- [ ] **`.env` file exists and complete** — no placeholder values
- [ ] **`env_file: .env` declared on EVERY service** that needs it (app, worker, scheduler, db migrations)
- [ ] **No secrets in compose file** — only `${VAR}` references
- [ ] **JWT secret ≥ 32 bytes** — generated via `openssl rand -hex 32`
- [ ] **Database password ≠ default** — rotated from `postgres` / `password`

### Database & Migrations
- [ ] **Migration script versioned** — `migrations/001_initial.sql`, `002_add_x.sql`, etc.
- [ ] **Migration runs in CI / predeploy step** — not on app startup (race condition risk)
- [ ] **Rollback script exists** for each migration (or `DOWN` SQL)
- [ ] **Backup taken before deploy** — `pg_dump` / volume snapshot

### Build & Image
- [ ] **Multi-stage Dockerfile** — build stage separate from runtime
- [ ] **Non-root user in final image** — `USER node` / `USER app`
- [ ] **Healthcheck defined** — `HEALTHCHECK CMD curl -f http://localhost:3000/health || exit 1`
- [ ] **Image tagged with git SHA** — `myapp:git-<sha>` + `myapp:latest`

---

## Post-Deploy Smoke Tests (Run Immediately After Deploy)

### 1. Health & Connectivity
```bash
# App health
curl -f https://app.domain.com/health

# DB connectivity from app
docker exec <app> pg_isready -h db -U $POSTGRES_USER

# External TLS endpoint (SMTP, payments, S3) from app container
docker exec <app> openssl s_client -connect smtp.host:587 -starttls smtp -servername smtp.host < /dev/null
# Must complete handshake (no hang at CONNECTED)
```

### 2. Critical User Flows (Automated or Manual)
- [ ] **Auth flow:** Register → verify email → login → access protected route
- [ ] **Password reset:** Request → receive email → click link → set new password → login
- [ ] **Core CRUD:** Create → Read → Update → Delete on primary entity
- [ ] **File upload** (if applicable) → S3 / local storage → serve back

### 3. Observability
- [ ] **Logs streaming** — `docker logs -f app` shows no ERROR/CRITICAL
- [ ] **Metrics endpoint** — `/metrics` returns Prometheus format (if applicable)
- [ ] **Alerting test** — fire a test alert (disk, CPU, error rate) → reaches on-call

---

## Rollback Procedure (Documented Per Project)

```bash
# 1. Tag current broken image
docker tag myapp:latest myapp:broken-<timestamp>

# 2. Deploy previous known-good tag
docker tag myapp:git-<previous-sha> myapp:latest
docker compose up -d --force-recreate app

# 3. Run smoke tests
# 4. If DB migration ran: execute DOWN migration
# 5. Post-mortem within 24h
```

## Common Framework Pitfalls

### Fastify Cookie `clearCookie` Domain Requirement
When using HTTPOnly cookies with explicit `domain` set (e.g., `payntra.terrybot.top`), `reply.clearCookie()` **must include the same domain, secure, and sameSite options** or the browser will not delete the cookie.

```typescript
// WRONG - cookie persists after logout
reply.clearCookie(COOKIE_NAME, { path: cookieOpts.path });

// CORRECT - matches setCookie options exactly
reply.clearCookie(COOKIE_NAME, {
  path: cookieOpts.path,
  domain: cookieOpts.domain,
  secure: cookieOpts.secure,
  sameSite: cookieOpts.sameSite,
});
```

This caused logout to appear to work (redirect to login) but session persisted on reload.

---

## Project Index Entry (Add to PROJECT_INDEX.md)

```markdown
## Deployment Metadata
- **Host MTU:** 1400
- **Docker Network:** payntra-net (MTU 1400)
- **SMTP:** mail.cyberslide.net:587 STARTTLS
- **DB:** postgres:16 on payntra-net
- **Healthcheck:** GET /health
- **Rollback Tag:** payntra:git-<last-known-good-sha>
```