---
name: docker-network-troubleshooting
description: "Diagnose and fix Docker network MTU mismatches, SMTP/TLS handshake failures, and container-to-container connectivity issues"
category: devops
tags: [docker, networking, mtu, smtp, tls, postgresql, troubleshooting]
---

# Docker Network MTU & Connectivity Troubleshooting

## The Core Lesson

**Docker's default bridge network uses MTU 1500. If your host interface (eth0, ens3, etc.) has MTU < 1500 (common on cloud VPS: 1400, 1450, 1460), TLS handshakes and large packets will silently fragment and drop.**

This manifests as:
- SMTP `STARTTLS` hanging after `220 Ready` (TLS ClientHello > 1500 bytes fragments)
- PostgreSQL connections timing out (`EAI_AGAIN`, connection refused)
- HTTPS API calls timing out intermittently
- `apt update` / `npm install` hanging inside containers

## Root Cause Checklist — Check These FIRST

### 1. Host MTU
```bash
ip link show eth0 | grep mtu
# or
cat /sys/class/net/eth0/mtu
```
**Expected:** Match this value in Docker network.

### 2. Docker Network MTU
```bash
docker network inspect <network_name> | grep -i mtu
```
## SMTP-Specific Debugging Order

When `nodemailer` / `sendmail` / `postfix` hangs on `STARTTLS`:

| Step | Command | What It Tells You |
|------|---------|-------------------|
| 1. TCP reachability | `nc -zv <host> 587` | Port open? Firewall? |
| 2. TLS handshake | `openssl s_client -starttls smtp -connect <host>:587 -servername <host>` | Hangs at `CONNECTED`? → **MTU issue** |
| 3. From container | `docker exec <app> nc -zv <host> 587` | Container egress works? |
| 4. From container TLS | `docker exec <app> openssl s_client ...` | Confirms MTU inside container |
| 5. Check MTU | `docker exec <app> ip link show eth0` | Container MTU ≠ Host MTU? |

**If Step 2 or 4 hangs after `CONNECTED(00000003)` → MTU mismatch. Full stop.**

### Root Cause: Docker Default Bridge MTU

Docker's default bridge network uses MTU 1500. Cloud VPS (Hetzner, AWS, GCP, DigitalOcean) often have host MTU 1400 (or 1450, 1460) due to VXLAN/GENEVE overlay.

**TLS ClientHello > 1500 bytes fragments and gets dropped.** The handshake never completes.

### The Fix Pattern

```yaml
# docker-compose.yml
networks:
  app-net:
    driver: bridge
    driver_opts:
      com.docker.network.driver.mtu: "1400"  # MATCH HOST MTU

services:
  app:
    networks: [app-net]
  db:
    networks: [app-net]  # CRITICAL: db must be on same network
  smtp-relay:
    networks: [app-net]
```

Then force recreate:
```bash
docker compose down
docker network rm <project>_app-net  # Force recreate with new MTU
docker compose up -d
```

## SMTP-Specific Debugging Order

When `nodemailer` / `sendmail` / `postfix` hangs on `STARTTLS`:

| Step | Command | What It Tells You |
|------|---------|-------------------|
| 1. TCP reachability | `nc -zv <host> 587` | Port open? Firewall? |
| 2. TLS handshake | `openssl s_client -starttls smtp -connect <host>:587 -servername <host>` | Hangs at `CONNECTED`? → **MTU issue** |
| 3. From container | `docker exec <app> nc -zv <host> 587` | Container egress works? |
| 4. From container TLS | `docker exec <app> openssl s_client ...` | Confirms MTU inside container |
| 5. Check MTU | `docker exec <app> ip link show eth0` | Container MTU ≠ Host MTU? |

**If Step 2 or 4 hangs after `CONNECTED(00000003)` → MTU mismatch. Full stop.**

## PostgreSQL-Specific Debugging

When app logs show `EAI_AGAIN db` or `connection refused`:

| Check | Command |
|-------|---------|
| Same network? | `docker network inspect <net> \| jq '.[0].Containers'` — both containers listed? |
| DNS resolution | `docker exec <app> getent hosts db` — returns IP? |
| Port reachable | `docker exec <app> nc -zv db 5432` |
| PG env vars | `docker exec <app> env \| grep -i postgres` — correct host/port? |

## Docker Image Cache Pitfall — CRITICAL

**Problem:** `docker compose build` with cached layers can serve stale code even after source changes.

**Symptoms:**
- Code changes (e.g., logout cookie fix) appear in local build but not in running container
- `docker exec <app> cat /app/dist/routes/auth.js` shows old code
- `--no-cache` sometimes still uses cached intermediate layers

**Fix Pattern:**
```bash
# 1. Full clean rebuild
docker compose build --no-cache --pull app

# 2. Verify artifact BEFORE restart
docker exec <app> cat /app/dist/routes/auth.js | grep -A 10 "logout"

# 3. Only then restart
docker compose up -d --force-recreate app
```

**Root cause:** Docker layer caching skips `COPY server/ ./` if file timestamps/metadata appear unchanged, or intermediate builder stages are reused. Always verify the built artifact inside the container before declaring deploy done.

## Prevention Checklist (Add to Every New Project)

- [ ] **Before first `docker compose up`:** Run `ip link show eth0` on host, note MTU
- [ ] **In `docker-compose.yml`:** Define custom network with `driver_opts: com.docker.network.driver.mtu: "<HOST_MTU>"`
- [ ] **Every service:** Explicitly declare `networks: [custom-net]` — no implicit default network
- [ ] **CI/CD gate:** Add a smoke test that hits an external TLS endpoint (SMTP, HTTPS API) from inside the app container
- [ ] **Document:** Record host MTU in project README / PROJECT_INDEX.md

## Related Skills
- `deployment-checklist` — add MTU verification to pre-deploy gates
- `postgresql-operations` — cross-reference container networking prerequisites