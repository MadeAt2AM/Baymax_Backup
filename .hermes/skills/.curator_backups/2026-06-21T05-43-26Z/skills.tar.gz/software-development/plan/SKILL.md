---
name: plan
description: "Plan mode: write markdown plan to .hermes/plans/, no exec."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [planning, plan-mode, implementation, workflow]
    related_skills: [writing-plans, subagent-driven-development]
---

# Plan Mode

Use this skill when the user wants a plan instead of execution.

## Sub-Skills

The `plan` skill also covers:
| Sub-Skill | When to Load It |
|-----------|----------------|
| `plan` | User invokes `/plan` — lightweight single-turn planning |
| `spike` | Validate an idea before committing — throwaway feasibility prototypes |
| `subagent-driven-development` | Execute a plan via subagents with two-stage review |

### Planning Methodology

- **Bite-sized tasks (2-5 min each)** — each step is one focused action
- **Exact file paths** — no "the config file", use `src/config/settings.py`
- **Complete code** — copy-pasteable examples, not pseudocode
- **Exact commands with expected output** — `pytest tests/x.py::test_y -v` expected: PASS
- **Verification steps** — prove the task works

For **full implementation plans** with TDD cycle, DRY/YAGNI principles, and BDD task structure, see the `writing-plans` skill (absorbed into `plan` as a reference).

## Core behavior

For this turn, you are planning only.

- Do not implement code.
- Do not edit project files except the plan markdown file.
- Do not run mutating terminal commands, commit, push, or perform external actions.
- You may inspect the repo or other context with read-only commands/tools when needed.
- Your deliverable is a markdown plan saved inside the active workspace under `.hermes/plans/`.

## Output requirements

Write a markdown plan that is concrete and actionable.

Include, when relevant:
- Goal
- Current context / assumptions
- Proposed approach
- Step-by-step plan
- Files likely to change
- Tests / validation
- Risks, tradeoffs, and open questions

If the task is code-related, include exact file paths, likely test targets, and verification steps.

## Save location

Save the plan with `write_file` under:
- `.hermes/plans/YYYY-MM-DD_HHMMSS-<slug>.md`

Treat that as relative to the active working directory / backend workspace. Hermes file tools are backend-aware, so using this relative path keeps the plan with the workspace on local, docker, ssh, modal, and daytona backends.

If the runtime provides a specific target path, use that exact path.
If not, create a sensible timestamped filename yourself under `.hermes/plans/`.

## Interaction style

- If the request is clear enough, write the plan directly.
- If no explicit instruction accompanies `/plan`, infer the task from the current conversation context.
- If it is genuinely underspecified, ask a brief clarifying question instead of guessing.
- After saving the plan, reply briefly with what you planned and the saved path.
